# Cucumber-ExtentReport4

**Clone the project Directory**

## Test Command

```
mvn clean verify
```

## Reports Folders

#### Find the Spark Report under test-output/Selenix-Spark
#### Find the HTML Report under test-output/HtmlReport/HtmlReport.html
#### Find the Logger Report under test-output/Selenix-Logger
